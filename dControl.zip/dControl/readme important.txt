How to use : https://blog.sombex.com/2021/06/how-to-disable-microsoft-defender-permanently-in-windows-11.html
Youtube channel: Sombex : https://www.youtube.com/channel/UCmcXVCxNwW5rp-KAc8qadbQ